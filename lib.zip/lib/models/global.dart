import 'package:flutter/material.dart';

// ignore: non_constant_identifier_names
Color dark_blue = Color(0xFF018197);

TextStyle buttonStyleblue =
    TextStyle(color: Colors.blue, fontFamily: "Helvetica");
TextStyle productTitleStyle = TextStyle(
    fontSize: 20, fontFamily: "Helvetica", fontWeight: FontWeight.bold);
TextStyle whiteItallictTitleStyle = TextStyle(
    fontSize: 20,
    fontFamily: "Helvetica",
    fontStyle: FontStyle.italic,
    color: Colors.white);
