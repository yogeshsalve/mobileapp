import 'package:flutter/material.dart';

const mainColor = Color(0xff2470c7);
