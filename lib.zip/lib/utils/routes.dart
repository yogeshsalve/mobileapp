class MyRoutes {
  static String loginRoute = "/login";
  static String storeRoute = "/store";
  static String buyRoute = "/buyform";
}
